#ifndef MATRIXOPERATIONS_H
#define MATRIXOPERATIONS_H
 
class matrix
{
	private:
		int maxrow,maxcol;
		double *ptr;
	
	public:
		matrix(int r,int c);
		matrix(int r);
		float getmat();
		void display();
		double determinant();
		matrix operator + (matrix b);
		matrix operator - (matrix b);
		matrix operator*(matrix b);
		int operator == (matrix b);
		matrix transpose();
		void display(double res);
		void identitymatrix(int r,int c);
		double* getpointer();
		matrix gibbins(int row1,int row2,double c,double s);
		matrix copy();
		matrix getcolumn(int col);
		double getcomp(int row,int col);
		matrix operator*(double b);
};
		matrix identity(int order);
		void display(double *A,int row,int col);
		
		
#endif


