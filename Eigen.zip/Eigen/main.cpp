#include<iostream>
#include<iomanip>
#include<time.h>
#include<math.h>
#include<stdlib.h>
#include "MatrixOperarions.h"


using namespace std;

int main()
{
	int order,i,j,k,col=1;
	float range;

	cout<<"ENTER ORDER OF THE MATRIX :";
	cin>>order;
	cout<<endl;

	double *ptra,*ptrq,x,y,det;
	matrix A(order),Q(order),G(order),R(order),vector(order),column(order,1),Acopy(order);

	range = A.getmat();

	if (range==0)
	{
		cout<<"PROGRAM TERMINATED "<<endl;
		return 0;
	}

	A.display();
	Acopy = A.copy();
	vector = identity(order);

	for (j=0;j<200;j++)
	{
		Q = identity(order);
		R = A.copy();
		for (k=0;k<order-1;k++)
		{
			for(i=k+1;i<order;i++)
			{
				ptra =R.getpointer();
				x=*(ptra + k*order +k);
				y=*(ptra + i*order +k);
				if (x==0&&y==0)
				continue;

				G= A.gibbins(k,i,x/sqrt(x*x+y*y),y/sqrt(x*x+y*y));
				R = G*R;
				Q = G*Q;
			}
		}
		Q =Q.transpose();
		vector = vector*Q;
		A = R*Q;
	}

	j=0;
	for (i=0;i<order;i++)
	{
		if (abs( (Acopy - identity(order)*A.getcomp(i,i)).determinant()) <= range*range*order*order)
		{
			cout<<"REAL EIGEN VALUE NUMBER "<<j+1<<"= "<<A.getcomp(i,i);
			vector.getcolumn(i).display();
			j++;
		}
	}
	return 0;
}




