#include<iostream>
#include<iomanip>
#include<time.h>
#include<math.h>
#include<stdlib.h>
#include "MatrixOperarions.h"

using namespace std;




	matrix::matrix(int r,int c) //constructor of the matrix class
		{
			maxrow=r; maxcol=c;
			ptr= new double[r*c]; /*allocates the memory of size
					   r*c and allocates the adrress
					   to pointer "ptr" */
		}


	matrix::matrix(int r) //constructor of the matrix class
		{
			maxrow=r; maxcol=r;
			ptr= new double[r*r]; /*allocates the memory of size
					   r*c and allocates the adrress
					   to pointer "ptr" */
		}




	float matrix::getmat()              //gets the matrix from user
		{
			int i,j,choise,range;

			cout<<"PRESS '0' FOR MANUAL OR '1' FOR RANDOM"<<endl;
			cin>>choise;

			if (choise ==0)  //To enter matrix manually
			{
				cout<<endl<<"Enter elements of matrix:"<<endl;
				for (i=0;i<maxrow;i++)
				{
					for (j=0;j<maxcol;j++)
					cin>>ptr[i*maxcol+j];
				}
			}

			else if (choise ==1) //to give random values to the matrix components
			{
				cout<<"CHOOSE RANGE OF ELEMENTS :";
				cin>>range;
				cout<<endl;
				srand(time(NULL));
				for (i=0;i<maxrow;i++)
				{
					for (j=0;j<maxcol;j++)
					ptr[i*maxcol+j]= float(rand()%range);
				}
			}

			else
				{
					cout<<"NOT VALID CHOISE"<<endl;
					return 0;
				}
		return range;
		}


	void matrix::display() //to display the matrix
		{
			int i,j,mat_off;

			for (i=0;i<maxrow;i++)
			{
				cout<<endl;
				for (j=0;j<maxcol;j++)
				 cout<<setw(15)<<ptr[i*maxcol+j];
			}cout<<endl<<endl;
		}


	double matrix::determinant() //get the determinant of the matrix
		{
			int i,j,k;
			double det=1.0,m[maxrow][maxrow],temp;

			if (maxrow!=maxcol)
				{
					cout<<"MATRIX MUST BE A SQUARE MATRIX"<<endl;
					return 0.0000000000001;
				}

			if (maxcol<=0)
				{
					cout<<"MATRIX MUST HAVE NON ZERO DIMENTIONS"<<endl;
					return 0.00000000000001;
				}

			for (i=0;i<maxrow;i++)
			{
				for (j=0;j<maxrow;j++)
				{
					m[i][j]	= ptr[i*maxcol+j];

				}
			}  det =m[0][0];

			for (k=0;k<maxcol-1;k++)
			{
				if (m[k][k]==0)
				{
					for(i=k+1;i<maxrow;i++)
					{
						if(m[i][0]!=0)
						{
							for (j=0;j<maxcol;j++)
							{
								temp=m[i][j];
								m[i][j]=m[0][j];
								m[0][j]=temp;
							}
							det = -det;
							break;
						}
					}
					if (i==maxrow)
						return 0;
				}

				for (i=k+1;i<maxcol;i++)
				{
					temp=m[i][k];
					for (j=0;j<maxcol;j++)
					{
						m[i][j] = m[i][j] - temp*m[k][j]/m[k][k];

					}
				}
				det = det*m[k+1][k+1];
			}
			return det;
		}


	matrix matrix::operator + (matrix b) //addition of two matrices
		{
			matrix c(maxrow,maxcol);
			int i,j,mat_off;

			for (i=0;i<maxrow;i++)
			{
				for (j=0;j<maxcol;j++)
				{
					mat_off =i*maxcol+j;
					c.ptr[mat_off] = ptr[mat_off] + b.ptr[mat_off];
				}

			}
			return(c);
		}

		matrix matrix::operator - (matrix b) //sibstraction of two matrices
		{
			matrix c(maxrow,maxcol);
			int i,j,mat_off;

			for (i=0;i<maxrow;i++)
			{
				for (j=0;j<maxcol;j++)
				{
					mat_off =i*maxcol+j;
					c.ptr[mat_off] = ptr[mat_off] - b.ptr[mat_off];
				}

			}
			return(c);
		}




	matrix matrix::operator*(matrix b) //matrix multiplication
		{
			matrix c(maxrow,b.maxcol);
			int i,j,k,mat_off1,mat_off2,mat_off3;


			if (maxcol!=b.maxrow)
			{
				cout<<"DIMENTION MISMATCH CANNOT MULTIPLY"<<endl;
				return c;
			}

			for (i=0;i<c.maxrow;i++)
			{
				for (j=0;j<c.maxcol;j++)
				{
					mat_off3 =i*c.maxcol+j;
					c.ptr[mat_off3] =0;

					for (k=0;k<maxcol;k++)
					{
						mat_off2 =k*b.maxcol+j;
						mat_off1 =i*maxcol+k;
						c.ptr[mat_off3] += ptr[mat_off1]*b.ptr[mat_off2];
						}
					}
			}
			return(c);
		}


		matrix matrix::operator*(double b) //scalar multiplication with matrix
		{
			matrix c(maxrow,maxcol);
			int i,j,mat_off;


			for (i=0;i<maxrow;i++)
			{
				for (j=0;j<maxcol;j++)
				{
					mat_off = i*maxcol+j;
					c.ptr[mat_off] = b*ptr[mat_off];
				}
			}
			return(c);
		}






	int matrix::operator == (matrix b) //equate two matrices
		{
			int i,j,mat_off;

			if(maxrow!=b.maxrow||maxcol!=b.maxcol)
			return 0;

			for(i=0;i<maxrow;i++)
			{
				for(j=0;j<maxcol;j++)
				{
					mat_off =i*maxcol+j;
					if(abs(ptr[mat_off] -b.ptr[mat_off])>0.00001)
					return 0;
				}
			}
			return 1;
		}

	matrix matrix::transpose() //transpose of matrix
		{
			int i,j,mat_off,mat_off1;
			double temp;
			matrix c(maxcol,maxrow);

			for (i=0;i<maxrow;i++)
			{
				for (j=0;j<maxcol;j++)
				{
					mat_off = i*maxcol+j;
					mat_off1= j*maxrow+i;
					temp = ptr[mat_off];
					c.ptr[mat_off1]=temp;
				}
			}
		return c;
		}




	void matrix::identitymatrix(int r,int c) //identity matrix I[r,c]
		{
			int mat_off;
			int i,j;

			for (i=0;i<r;i++)
			{
				for (j=0;j<c;j++)
				{
					mat_off = i*maxcol+j;
					if (i==j)
						ptr[mat_off]=1.0;
					else
						ptr[mat_off]=0.0;
				}
			}
		}







	matrix identity(int order) //square identity matrix I[o,o]
		{
			int i,j,mat_off;
			matrix m(order);
			m.identitymatrix(order,order);

			return m;
		}

	 double* matrix::getpointer() //get the pointer of matrix object
		{
		return (ptr);
		}



	void display(double *A,int row,int col) //DISPLAY TWO DIMENTIONAL ARRAY
		{
			for (int i=0;i<row;i++)
			{
				cout<<endl;
				for (int j=0;j<col;j++)
				{
					cout<<setw(5)<<*(A+i*col+j);

				}
			} cout<<endl;
		}


	matrix matrix::gibbins(int row1,int row2,double c,double s)

		{

			matrix m(maxrow,maxcol);
			m.identitymatrix(maxrow,maxcol);

			if (row1>maxrow || row2>maxrow)
				{cout<< "INPUT ROW OR COLUMN IS GREATER THAN INPUT MATRIX ROW OR COLUMN"<<endl;
				return m;}

			else
			{
				m.ptr[row1*m.maxcol+row1] = c;
				m.ptr[row2*m.maxcol+row2] = c;
				m.ptr[row1*m.maxcol+row2] = s;
				m.ptr[row2*m.maxcol+row1] = -s;
				return m;
			}
		}

	matrix matrix::copy() //copy one matrix into another
		{
			int i,j,mat_off;

			matrix c(maxcol,maxrow);

			for (i=0;i<maxrow;i++)
			{
				for (j=0;j<maxcol;j++)
				{
					mat_off = i*maxcol+j;
					c.ptr[mat_off]=ptr[mat_off];
				}
			}
		return c;
		}

	matrix matrix::getcolumn(int col) //get column of the matrix
		{
			int i,mat_off,mat_off1;
			matrix column(maxrow,1);

			for (i=0;i<maxrow;i++)
			{
				mat_off = i*maxrow + col;
				mat_off1 = i;
				column.ptr[mat_off1] =ptr[mat_off];
			}
		return column;
		}

	double matrix::getcomp(int row,int col) //get matrix component
		{
			int mat_off;
			double s;
			mat_off = row*maxcol+col;
			s = ptr[mat_off];
			return s;
		}









