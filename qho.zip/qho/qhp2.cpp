#include <iostream>
#include <math.h>
#include <fstream>

int psix(float M,float W,float E);
void normalize_and_plot(float a[],int nop,float xfinal,float dx);
void append();
using namespace std;

int main()
{

	float dx,M,W,E;
	int nop;
	

	cout<<"MASS OF THE OSCILLATOR = "<<endl;
	cin>>M;

	cout<<"FREQUENCY OF THE OSCILLATOR =  "<<endl;
	cin>>W;

	cout <<"Trial energy  = "<<endl;
	cin >>E;
		
		
	psix(M,W,E);  //calculate all the point to point values of the wavefunction

	

return 0;
}


int psix(float M,float W,float E)
{
	int nop=30,n;
	float j=0.0,psiofx[2*nop-1],xcl,xlimit,xfinal,dx;
	float a,b,y=0,c=0,v=1,d=1;
		
	xcl = sqrt(2*E/(M*W*W));
	xlimit = sqrt(2.5*E/(M*W*W));
	xfinal =xcl;
		
	n=10000;     //grid points for each value
	dx=xfinal/(n*nop);

	
	
	for (int i=0;i<=2*nop-1;i++)
	{
		psiofx[i]=0;
		
	}
	
	
	
	
		for(int m=0;m>=-nop;m--)
		{	
			for(float x=0.00000;x>-xfinal/nop;x=x-dx)
			{
				j=j-dx;		
				a=c;
				b=d;	
				d= b - dx*(M*W*W*j*j*a-2*M*E*a);
				c=-dx*b+a;
			}
    	
			
			psiofx[m+nop]=c;
				
		}

		j=0.0;

		for(int m=0;m<=nop;m++)
		{	
			for(float x=0.00000;x<=xfinal/nop;x=x+dx)
			{
				j=j+dx;		
				a=y;
				b=v;	
				v= b + dx*(M*W*W*j*j*a-2*M*E*a);
				y=dx*b+a;
			}	

			
			psiofx[m+nop-1]=y;
		}
	cout<<"last y ="<<y<<endl;cout<<"last v= "<<v<<endl;
	normalize_and_plot(psiofx,nop,xfinal,dx);
}
















void normalize_and_plot(float b[],int NOP,float xfinal,float dx)
{
	double sum=0.0,j=-xfinal,nsum=0.0;	
	
	ofstream quantumh_euler;	
	quantumh_euler.open("qho2.txt");
	
	//for (int i=0;i<=2*NOP-1;i++)
	//{
		cout<<b[2*NOP-1]<<endl;	
	//}
		
	for (int i=0;i<=2*NOP-1;i++)
	{
		sum = sum +b[i]*b[i]*2*xfinal/(2*NOP-1);	
	}
	//cout<<sum<<endl;
	nsum=0.0;

	for (int i=0;i<=2*NOP-1;i++)
	{
		quantumh_euler <<j<<" "<<b[i]/sqrt(sum)<<endl;
		j= j+2*xfinal/(2*NOP-1);
	      	nsum=nsum+b[i]*b[i]*2*xfinal/((2*NOP-1)*sum);	
	}
	 
	cout <<"Total probability of finding the particle = "<<nsum<<endl;
	quantumh_euler.close();
}













